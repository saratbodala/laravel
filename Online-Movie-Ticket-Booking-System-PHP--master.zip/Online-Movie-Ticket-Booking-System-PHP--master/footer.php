<footer>
    <div class="container"> 
        <center> 
            <p>Copyright &copy; MovieTicks.com. All Rights Reserved | Contact Us: +91 90000 00000</p> 
        </center> 
    </div> 
</footer>










